# Android Signal App (Complete)

This project contains a runnable skeleton Android app with:
- Jetpack Compose UI
- Retrofit API client
- SMA, EMA, RSI calculation
- Simple BUY/SELL/HOLD signal engine
- Alpha Vantage data fetcher

Replace YOUR_API_KEY in MainActivity.kt.
