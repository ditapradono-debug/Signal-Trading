package com.example.signals

data class PricePoint(val date: String, val close: Double)
