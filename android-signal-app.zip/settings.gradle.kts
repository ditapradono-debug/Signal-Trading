rootProject.name="android-signal-app"
include(":app")