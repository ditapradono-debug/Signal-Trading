Android Signal App Skeleton
Replace YOUR_API_KEY in MainActivity.kt.